// backend/types/area.types.ts

/**
 * Define la estructura de la entidad Area.
 */
export interface Area {
  id: string;
  defaultname: string;
}