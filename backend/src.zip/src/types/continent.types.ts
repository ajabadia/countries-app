// backend/types/continent.types.ts

/**
 * Define la estructura de la entidad Continent.
 */
export interface Continent {
  id: string;
  defaultname: string;
}