import { Component, inject, signal, OnInit, OnDestroy, Injector } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpParams } from '@angular/common/http';
import { Subscription, combineLatest, of } from 'rxjs';
import { switchMap, catchError, tap, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { toObservable } from '@angular/core/rxjs-interop';

import { UiHeadingComponent } from '@app/shared/components/ui-heading/ui-heading.component';
import { UiTableComponent } from '@app/shared/components/ui-table/ui-table.component';
import { TableColumn } from '@app/shared/components/ui-table/table.types';
import { Sort } from '@app/shared/types/sort.type';

import { ContinentsService } from './continents.service';
import { Continent } from '@app/core/types/continent.types';
import { PagedResponse } from '@app/shared/types/paged-response.interface';

@Component({
  selector: 'app-continents-admin',
  standalone: true,
  imports: [CommonModule, UiHeadingComponent, UiTableComponent],
  templateUrl: './continents-admin.component.html',
})
export class ContinentsAdminComponent implements OnInit, OnDestroy {
  private injector = inject(Injector);
  private continentsService = inject(ContinentsService);

  // --- Estado y Signals ---
  pageTitle = 'Gestión de Continentes';
  data = signal<Continent[]>([]);
  totalRecords = signal(0);
  isLoading = signal(true);

  // Signals para controlar el estado de la tabla
  page = signal(1);
  pageSize = signal(10);
  sort = signal<Sort<Continent>>({ orderBy: 'id', orderDir: 'asc' });

  private dataSubscription: Subscription | null = null;

  ngOnInit(): void {
    const page$ = toObservable(this.page, { injector: this.injector });
    const pageSize$ = toObservable(this.pageSize, { injector: this.injector });
    const sort$ = toObservable(this.sort, { injector: this.injector });

    this.dataSubscription = combineLatest([page$, pageSize$, sort$]).pipe(
      tap(() => this.isLoading.set(true)),
      switchMap(([page, pageSize, sort]) => {
        let params = new HttpParams()
          .set('page', page.toString())
          .set('pageSize', pageSize.toString())
          .set('orderBy', sort.orderBy as string)
          .set('orderDir', sort.orderDir);
        return this.continentsService.getAll(params).pipe(
          catchError(() => of({
            data: [],
            total: 0,
            page: 1,
            pageSize: 10,
            totalPages: 0,
            hasNextPage: false,
            hasPrevPage: false,
          } as PagedResponse<Continent>))
        );
      })
    ).subscribe(response => {
      this.data.set(response.data);
      this.totalRecords.set(response.total);
      this.isLoading.set(false);
    });
  }

  ngOnDestroy(): void {
    this.dataSubscription?.unsubscribe();
  }

  onSortChange(newSort: Sort<Continent>): void {
    this.sort.set(newSort);
  }

  columns: TableColumn<Continent>[] = [
    { key: 'id', label: 'ID', sortable: true },
    { key: 'defaultname', label: 'Nombre', sortable: true },
  ];
}