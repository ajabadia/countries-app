import { Component, inject, signal, OnInit, OnDestroy, Injector } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpParams } from '@angular/common/http';
import { Subscription, combineLatest, of } from 'rxjs';
import { switchMap, catchError, tap, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { toObservable } from '@angular/core/rxjs-interop';

import { CountriesService } from './countries.service';
import type { Country } from '@app/core/types/country.types';
import { TableColumn } from '@app/shared/components/ui-table/table.types';
import { UiTableComponent } from '@app/shared/components/ui-table/ui-table.component';
import { UiHeadingComponent } from '@app/shared/components/ui-heading/ui-heading.component';
import { UiPaginatorComponent } from '@app/shared/components/ui-paginator/ui-paginator.component';
import { PaginatorChangeEvent } from '@app/shared/components/ui-paginator/ui-paginator.types';
import { UiSearchBoxComponent } from '@app/shared/components/ui-search-box/ui-search-box.component';
import { UiTableColumnDirective } from '@app/shared/components/ui-table/ui-table-column.directive';
import { UiIconComponent } from '@app/shared/components/ui-icon/ui-icon.component';
import { Sort } from '@app/shared/types/sort.type';
import { PagedResponse } from '@app/shared/types/paged-response.interface';

@Component({
  selector: 'app-countries-admin',
  standalone: true,
  imports: [
    CommonModule,
    UiTableComponent,
    UiHeadingComponent,
    UiPaginatorComponent,
    UiSearchBoxComponent,
    UiTableColumnDirective,
    UiIconComponent,
  ],
  templateUrl: './countries-admin.component.html',
})
export class CountriesAdminComponent implements OnInit, OnDestroy {
  private injector = inject(Injector);
  private countriesService = inject(CountriesService);

  pageTitle = 'Países';

  // --- Estado y Signals ---
  data = signal<Country[]>([]);
  totalRecords = signal(0);
  isLoading = signal(true);

  // Signals para controlar el estado
  page = signal(1);
  pageSize = signal(10);
  sort = signal<Sort<Country>>({ orderBy: 'id', orderDir: 'asc' });
  searchTerm = signal('');

  private dataSubscription: Subscription | null = null;
  columns: TableColumn<Country>[] = [];

  ngOnInit(): void {
    this.initializeDataStream();
    this.initializeColumns();
  }

  private initializeDataStream(): void {
    const page$ = toObservable(this.page, { injector: this.injector });
    const pageSize$ = toObservable(this.pageSize, { injector: this.injector });
    const sort$ = toObservable(this.sort, { injector: this.injector });
    const searchTerm$ = toObservable(this.searchTerm, { injector: this.injector }).pipe(
      debounceTime(300),
      distinctUntilChanged()
    );

    this.dataSubscription = combineLatest([page$, pageSize$, sort$, searchTerm$]).pipe(
      tap(() => this.isLoading.set(true)),
      switchMap(([page, pageSize, sort, search]) => {
        let params = new HttpParams()
          .set('page', page.toString())
          .set('pageSize', pageSize.toString())
          .set('orderBy', sort.orderBy as string)
          .set('orderDir', sort.orderDir);
        if (search) {
          params = params.set('search', search);
          ['id', 'defaultname', 'alpha2may', 'alpha3may', 'numeric'].forEach(field => {
            params = params.append('searchFields', field);
          });
        }
        return this.countriesService.getAll(params).pipe(
          catchError(() => of({
            data: [],
            total: 0,
            page: 1,
            pageSize: 10,
            totalPages: 0,
            hasNextPage: false,
            hasPrevPage: false,
          } as PagedResponse<Country>))
        );
      })
    ).subscribe(response => {
      this.data.set(response.data);
      this.totalRecords.set(response.total);
      this.isLoading.set(false);
    });
  }

  constructor() {
    this.columns = [
      { key: 'id', label: 'ID' },
      {
        key: 'defaultname',
        label: 'Nombre',
        sortable: true,
        template: true // Indicamos que esta columna usará una plantilla
      },
      { key: 'alpha2may', label: 'ISO2', sortable: true },
      { key: 'alpha3may', label: 'ISO3', sortable: true },
      { key: 'numeric', label: 'Código Numérico', sortable: true },
    ];
  }

  private initializeColumns(): void {
    this.columns = [
      { key: 'id', label: 'ID', sortable: true },
      { key: 'defaultname', label: 'Nombre', sortable: true, template: true },
      { key: 'alpha2may', label: 'ISO2', sortable: true },
      { key: 'alpha3may', label: 'ISO3', sortable: true },
      { key: 'numeric', label: 'Código Numérico', sortable: true },
    ];
  }

  ngOnDestroy(): void {
    this.dataSubscription?.unsubscribe();
  }

  onSortChange(newSort: Sort<Country>): void { this.sort.set(newSort); }
  onSearch(newSearchTerm: string): void { this.searchTerm.set(newSearchTerm); }
  onPageStateChange(event: PaginatorChangeEvent): void {
    this.page.set(event.page);
    this.pageSize.set(event.pageSize);
  }
}