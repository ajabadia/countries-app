export const environment = {
  production: true,
  // URL de tu API de backend para el entorno de producción
  apiUrl: 'https://api.tu-dominio.com/api' // ¡Recuerda cambiar esto!
};