export const environment = {
  production: false,
  // URL de tu API de backend para el entorno de desarrollo
  apiUrl: 'http://localhost:3000/api'
};