import { Component } from '@angular/core';

@Component({
  selector: 'app-dependencies-admin',
  standalone: true,
  template: `<p>dependencies-admin works!</p>`,
})
export class DependenciesAdminComponent {}