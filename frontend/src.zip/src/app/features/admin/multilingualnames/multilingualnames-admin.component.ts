import { Component } from '@angular/core';

@Component({
  selector: 'app-multilingualnames-admin',
  standalone: true,
  template: `<p>multilingualnames-admin works!</p>`,
})
export class MultilingualnamesAdminComponent {}