export interface Language {
  id: string;
  name: string;
  active: number; // 0 (inactivo) o 1 (activo)
}