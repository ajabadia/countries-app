/**
 * Define la estructura de la entidad Area para el frontend.
 */
export interface Area {
  id: string;
  defaultname: string;
}