// File: /frontend/src/app/app.routes.ts

import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    // ✅ CORRECCIÓN: Se carga directamente el nuevo HomeComponent (standalone)
    // que está en la ruta correcta, eliminando la dependencia con el
    // antiguo fichero de rutas que causaba el error.
    loadComponent: () =>
      import('@features/public/home/home.component').then(m => m.HomeComponent),
  },
  {
    path: 'admin',
    // Carga diferida de todas las rutas de administración
    loadChildren: () =>
      import('@features/admin/admin.routes').then(m => m.ADMIN_ROUTES),
  },
    {
    path: 'auth',
    loadChildren: () => import('./features/auth/auth.routes').then(m => m.AUTH_ROUTES),
  },
  {
    // ✅ CORRECCIÓN: Se asigna un segmento de ruta explícito para las rutas de usuario.
    path: 'user',
    loadChildren: () => import('./features/user/user.routes').then(m => m.USER_ROUTES)
  },
];