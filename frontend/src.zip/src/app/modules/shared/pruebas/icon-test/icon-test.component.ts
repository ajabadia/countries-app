import { Component } from '@angular/core';

@Component({
    selector: 'app-icon-test',
    templateUrl: './icon-test.component.html',
    styleUrls: ['./icon-test.component.scss'],
    standalone: false
})
export class IconTestComponent {

}
