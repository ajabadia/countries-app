// File: d:\desarrollos\countries2\frontend\src\app\core\services\notification.service.ts | New File

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  showError(message: string): void {
    console.error('NOTIFICATION_ERROR:', message);
  }
}