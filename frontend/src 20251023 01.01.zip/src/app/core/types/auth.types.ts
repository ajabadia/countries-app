// File: d:\desarrollos\countries2\frontend\src\app\core\types\auth.types.ts | New File

import { User } from '@core/types/user.types';

export interface AuthCredentials {
  email: string;
  password?: string;
}

export interface AuthResponse {
  user: User;
  accessToken: string;
}