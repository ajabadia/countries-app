export interface Country {
  id: string;
  alpha2may: string;
  alpha3may: string;
  numeric: string;
  defaultname: string;
}