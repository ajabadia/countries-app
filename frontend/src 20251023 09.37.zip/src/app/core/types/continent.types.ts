/**
 * Define la estructura de la entidad Continent para el frontend.
 */
export interface Continent {
  id: string;
  defaultname: string;
}